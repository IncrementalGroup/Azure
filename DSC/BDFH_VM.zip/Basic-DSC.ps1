﻿Configuration BD4H {
  
    # Import the module that contains the resources we're using.
    Import-DscResource -ModuleName cChoco
    
    Install-Module AzureRM -Force
    Install-Module SQLServer -Force

    Node("localhost") {
        cChocoInstaller installChoco{
            InstallDir = 'C:\ProgramData\chocolatey'
        }
        cChocoPackageInstaller installGit
        {
            Name = "git"
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = "[cChocoInstaller]installChoco"

        }
        cChocoPackageInstaller install7zip
        {
            Name = "7zip"
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = "[cChocoInstaller]installChoco"
        }
        cChocoPackageInstaller installChrome
        {
            Name = "googlechrome"
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = "[cChocoInstaller]installChoco"
        }
        cChocoPackageInstaller installvscode
        {
            Name = "vscode"
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = "[cChocoInstaller]installChoco"
        }
        cChocoPackageInstaller notepadplusplus
        {
            Name = "notepadplusplus"
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = "[cChocoInstaller]installChoco"
        }
        cChocoPackageInstaller installSQLstudio
        {
            Name = "sql-server-management-studio"
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = "[cChocoInstaller]installChoco"
        }
        cChocoPackageInstaller storageexplorer
        {
            Name = "microsoftazurestorageexplorer"
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = "[cChocoInstaller]installChoco"
        }
    }
}
