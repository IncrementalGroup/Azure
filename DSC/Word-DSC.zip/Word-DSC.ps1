﻿Configuration Word {
  
    # Import the module that contains the resources we're using.
    Import-DscResource -ModuleName cChoco

    Node("localhost") {
        cChocoInstaller installChoco{
            InstallDir = 'C:\ProgramData\chocolatey'
        }
        cChocoPackageInstaller installGit
        {
            Name = "office365proplus"
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = "[cChocoInstaller]installChoco"

        }

    }
}
